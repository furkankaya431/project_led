var group___touch_event =
[
    [ "NexTouch", "class_nex_touch.html", [
      [ "NexTouch", "class_nex_touch.html#a9e028e45e0d2d2cc39c8bf8d03dbb887", null ],
      [ "attachPop", "class_nex_touch.html#a4da1c4fcdfadb7eabfb9ccaba9ecad11", null ],
      [ "attachPush", "class_nex_touch.html#a685a753aae5eb9fb9866a7807a310132", null ],
      [ "detachPop", "class_nex_touch.html#af656640c1078a553287a68bf792dd291", null ],
      [ "detachPush", "class_nex_touch.html#a2bc36096119534344c2bcd8021b93289", null ]
    ] ],
    [ "NEX_EVENT_POP", "group___touch_event.html#ga5db3d99f88ac878875ca47713b7a54b6", null ],
    [ "NEX_EVENT_PUSH", "group___touch_event.html#ga748c37a9bbe04ddc680fe1686154fefb", null ],
    [ "NexTouchEventCb", "group___touch_event.html#ga162dea47b078e8878d10d6981a9dd0c6", null ]
];